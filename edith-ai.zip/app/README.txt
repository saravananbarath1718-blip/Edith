EDITH - build steps
1. Android Studio -> New Project -> "Empty Views Activity" (Kotlin), Name: Edith, Package: com.edith.assistant, Min SDK 28
2. Replace AndroidManifest.xml and MainActivity.kt with these files
3. Build > Build APK(s)  ->  app/build/outputs/apk/debug/app-debug.apk
4. Install on phone, allow all permissions
