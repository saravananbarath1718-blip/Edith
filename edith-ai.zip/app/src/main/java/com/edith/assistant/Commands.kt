package com.edith.assistant

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import java.util.Calendar

/**
 * Tamil / Tanglish / English voice commands.
 * Wake word "Edith" venum. Venaam na REQUIRE_WAKE = false pannunga.
 */
class Commands(private val ctx: Context, private val say: (String, String) -> Unit) {

    companion object {
        const val REQUIRE_WAKE = true
        val WAKE = listOf("edith", "edit", "எடித்", "எடிட்", "ஈடித்", "எடித", "ஈடிட்")
    }

    private val alarmW = listOf("alarm", "அலாரம்", "அலாரத்தை", "அலார்ம்")
    private val cancelW = listOf("cancel", "delete", "ரத்து", "நீக்கு")
    private val offW = listOf("off", "ஆஃப்", "அணை", "நிறுத்து", "நிறுத்து", "stop")
    private val rejectW = listOf("reject", "cut", "decline", "hang", "கட்", "ரிஜெக்ட்", "நிராகரி", "துண்டி")
    private val callW = listOf("call", "phone", "dial", "கால்", "போன்", "அழை", "கூப்பிடு", "பேசு")
    private val flashW = listOf("torch", "flash", "light", "டார்ச்", "ஃப்ளாஷ்", "ஃபிளாஷ்", "ப்ளாஷ்", "விளக்கு", "லைட்")
    private val timeW = listOf("time", "நேரம்", "டைம்", "மணி")
    private val calW = listOf("calendar", "calender", "கேலண்டர்", "நாள்காட்டி", "நாட்காட்டி")
    private val mapW = listOf("map", "maps", "மேப்", "மேப்ஸ்", "வரைபடம்", "navigate", "வழி")
    private val searchW = listOf("search", "தேடு", "தேடி", "சர்ச்")
    private val closeW = listOf("close", "மூடு", "குளோஸ்", "க்ளோஸ்")
    private val openW = listOf("open", "ஓபன்", "திற", "தொற", "தெற", "thira")
    private val fillers = listOf(
        "pannu", "pannunga", "பண்ணு", "பண்ணுங்க", "பன்னு", "செய்", "sollu", "please", "pls",
        "vai", "வை", "kku", "க்கு", "ku", "la", "ல", "ஒரு", "on", "ஆன்", "போடு", "podu"
    )
    private val allKeywords = alarmW + cancelW + offW + rejectW + callW + flashW + timeW +
        calW + mapW + searchW + closeW + openW

    private val aliases = mapOf(
        "வாட்ஸ்அப்" to "whatsapp", "வாட்ஸ் அப்" to "whatsapp", "யூடியூப்" to "youtube",
        "யூட்யூப்" to "youtube", "கேமரா" to "camera", "குரோம்" to "chrome",
        "இன்ஸ்டாகிராம்" to "instagram", "பேஸ்புக்" to "facebook", "டெலிகிராம்" to "telegram",
        "செட்டிங்ஸ்" to "settings", "செட்டிங்" to "settings", "கேலரி" to "gallery",
        "கடிகாரம்" to "clock", "கிளாக்" to "clock", "மெசேஜ்" to "messages",
        "கால்குலேட்டர்" to "calculator", "ஸ்பாட்டிஃபை" to "spotify", "ஜிமெயில்" to "gmail",
        "கூகுள் பே" to "google pay", "போன்பே" to "phonepe", "பிளே ஸ்டோர்" to "play store"
    )

    fun handle(results: List<String>) {
        for (r in results) if (process(r)) return
    }

    private fun has(t: String, l: List<String>) = l.any { t.contains(it) }

    private fun process(raw: String): Boolean {
        var t = raw.lowercase().trim()
        if (REQUIRE_WAKE) {
            val w = WAKE.firstOrNull { t.contains(it) } ?: return false
            t = t.replace(w, " ")
        }
        for ((k, v) in aliases) t = t.replace(k, v)
        t = t.replace(Regex("\\s+"), " ").trim()
        val rest = strip(t)

        if (t.isEmpty()) {
            say("சொல்லுங்க", "Yes?")
            return true
        }
        if (has(t, alarmW)) {
            if (has(t, offW) || has(t, cancelW)) dismissAlarm(t) else setAlarm(t)
            return true
        }
        if (has(t, rejectW) && (has(t, callW) || isRinging())) {
            rejectCall(); return true
        }
        if (has(t, flashW)) {
            torch(!has(t, offW)); return true
        }
        if (has(t, timeW)) {
            tellTime(); return true
        }
        if (has(t, calW)) {
            startAct(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
            say("கேலண்டர் திறக்கிறேன்", "Opening calendar")
            return true
        }
        if (has(t, mapW)) {
            val uri = if (rest.isBlank()) "geo:0,0" else "geo:0,0?q=" + Uri.encode(rest)
            startAct(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
            say("மேப் திறக்கிறேன்", "Opening maps")
            return true
        }
        if (has(t, searchW)) {
            if (rest.isBlank()) {
                say("என்ன தேடணும்?", "What should I search?")
            } else {
                startAct(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, rest))
                say("தேடுகிறேன்", "Searching")
            }
            return true
        }
        if (has(t, closeW)) {
            val svc = EdithAccessibilityService.instance
            if (svc == null) {
                say("Accessibility ON பண்ணுங்க", "Please turn on accessibility for Edith")
            } else {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                say("சரி", "Done")
            }
            return true
        }
        if (has(t, callW) && callContact(rest)) return true
        if (openApp(rest)) return true
        if (has(t, callW)) {
            say("அந்த contact கிடைக்கலை", "I could not find that contact")
            return true
        }
        if (has(t, openW)) {
            say("அந்த app கிடைக்கலை", "I could not find that app")
            return true
        }
        return false
    }

    // ---------- helpers ----------

    private fun strip(t: String): String {
        val kws = allKeywords + fillers
        return t.split(Regex("\\s+")).filter { tok ->
            tok.isNotBlank() && !kws.any { k -> tok == k || (k.length >= 3 && tok.startsWith(k)) }
        }.joinToString(" ")
    }

    private fun startAct(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = EdithAccessibilityService.instance ?: ctx
        try {
            c.startActivity(i)
        } catch (e: Exception) {
            say("திறக்க முடியலை", "Could not open it")
        }
    }

    private val tamilMap = mapOf(
        'க' to 'k', 'ங' to 'n', 'ச' to 's', 'ஞ' to 'n', 'ட' to 't', 'ண' to 'n', 'த' to 't',
        'ந' to 'n', 'ப' to 'p', 'ம' to 'm', 'ய' to 'y', 'ர' to 'r', 'ல' to 'l', 'வ' to 'v',
        'ழ' to 'l', 'ள' to 'l', 'ற' to 'r', 'ன' to 'n', 'ஜ' to 'j', 'ஷ' to 's', 'ஸ' to 's', 'ஹ' to 'h'
    )

    /** Tamil & English ellathaiyum oru "consonant skeleton" aa maathum, fuzzy match ku. */
    private fun skeleton(w: String): String {
        val s = w.lowercase()
            .replace("ch", "s").replace("sh", "s").replace("th", "t").replace("dh", "t")
            .replace("kh", "k").replace("gh", "k").replace("ph", "p").replace("bh", "p")
        val sb = StringBuilder()
        for (ch in s) {
            val m = tamilMap[ch]
            if (m != null) {
                sb.append(m)
            } else if (ch in 'a'..'z' && ch !in "aeiou") {
                sb.append(
                    when (ch) {
                        'g', 'c', 'q', 'x' -> 'k'
                        'd' -> 't'
                        'b', 'f' -> 'p'
                        'z' -> 's'
                        'w' -> 'v'
                        else -> ch
                    }
                )
            }
        }
        return sb.toString()
    }

    private fun score(rest: String, tokSk: List<String>, name: String): Int {
        val n = name.lowercase().trim()
        if (n.length >= 3 && rest.contains(n)) return 100 + n.length
        var s = 0
        for (nt in n.split(Regex("[\\s._\\-]+")).filter { it.isNotEmpty() }) {
            val ns = skeleton(nt)
            if (ns.length >= 2 && tokSk.any { it.startsWith(ns) }) s += ns.length
        }
        return s
    }

    private fun tokensSk(rest: String) =
        rest.split(Regex("\\s+")).filter { it.isNotBlank() }.map { skeleton(it) }

    // ---------- actions ----------

    private fun openApp(rest: String): Boolean {
        if (rest.isBlank()) return false
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val tokSk = tokensSk(rest)
        var best: ResolveInfo? = null
        var bs = 0
        for (ri in pm.queryIntentActivities(li, 0)) {
            val s = score(rest, tokSk, ri.loadLabel(pm).toString())
            if (s > bs) { bs = s; best = ri }
        }
        val b = best
        if (b == null || bs < 3) return false
        val launch = pm.getLaunchIntentForPackage(b.activityInfo.packageName) ?: return false
        say("${b.loadLabel(pm)} திறக்கிறேன்", "Opening ${b.loadLabel(pm)}")
        startAct(launch)
        return true
    }

    private fun callContact(rest: String): Boolean {
        if (rest.isBlank()) return false
        val tokSk = tokensSk(rest)
        var bestName: String? = null
        var bestNum: String? = null
        var bestScore = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val s = score(rest, tokSk, name)
                    if (s > bestScore) { bestScore = s; bestName = name; bestNum = num }
                }
            }
        } catch (e: SecurityException) {
            say("Contacts permission கொடுங்க", "Please give contacts permission")
            return true
        }
        val nm = bestName
        val nu = bestNum
        if (nm == null || nu == null || bestScore < 2) return false
        say("$nm க்கு கால் பண்றேன்", "Calling $nm")
        startAct(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(nu))))
        return true
    }

    private fun isRinging(): Boolean = try {
        (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager)
            .callState == TelephonyManager.CALL_STATE_RINGING
    } catch (e: Exception) {
        false
    }

    @Suppress("DEPRECATION")
    private fun rejectCall() {
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val ok = tm.endCall()
            if (ok) say("கால் கட் பண்ணிட்டேன்", "Call ended")
        } catch (e: SecurityException) {
            say("Phone permission கொடுங்க", "Please give phone permission")
        }
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                say("Flash இல்லை", "No flashlight found")
                return
            }
            cm.setTorchMode(id, on)
            say(if (on) "டார்ச் ஆன்" else "டார்ச் ஆஃப்", if (on) "Torch on" else "Torch off")
        } catch (e: Exception) {
            say("டார்ச் வேலை செய்யலை", "Torch failed")
        }
    }

    private fun tellTime() {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val m = c.get(Calendar.MINUTE)
        val am = c.get(Calendar.AM_PM) == Calendar.AM
        val mm = m.toString().padStart(2, '0')
        say(
            "இப்போது ${if (am) "காலை" else "மாலை"} $h மணி $m நிமிடம்",
            "It is $h:$mm ${if (am) "AM" else "PM"}"
        )
    }

    private val tamilNums = listOf(
        "பன்னிரண்டு" to 12, "பதினொன்று" to 11, "ஒன்பது" to 9, "இரண்டு" to 2, "மூன்று" to 3,
        "நான்கு" to 4, "ஐந்து" to 5, "பத்து" to 10, "ஒன்று" to 1, "ஆறு" to 6, "ஏழு" to 7,
        "எட்டு" to 8, "ஒரு" to 1
    )

    private fun parseTime(t: String): Pair<Int, Int>? {
        var h: Int? = null
        var m = 0
        val r1 = Regex("\\b(\\d{1,2})\\s*[:.]\\s*(\\d{2})\\b").find(t)
            ?: Regex("\\b(\\d{1,2})\\s+(\\d{2})\\b").find(t)
        if (r1 != null) {
            h = r1.groupValues[1].toInt()
            m = r1.groupValues[2].toInt()
        } else {
            val r2 = Regex("\\b(\\d{1,2})\\b").find(t)
            if (r2 != null) {
                h = r2.groupValues[1].toInt()
            } else {
                h = tamilNums.firstOrNull { t.contains(it.first) }?.second
            }
            if (t.contains("அரை") || t.contains("half")) m = 30
        }
        if (h == null || h > 23 || m > 59) return null

        val pmCue = has(t, listOf("மாலை", "evening", "night", "இரவு", "நைட்", "மதியம்", "afternoon", "பிற்பகல்")) ||
            Regex("\\bp\\.?m\\b").containsMatchIn(t)
        val amCue = has(t, listOf("காலை", "morning", "அதிகாலை", "விடியற்காலை")) ||
            Regex("\\ba\\.?m\\b").containsMatchIn(t)

        var hour: Int = h
        if (hour in 1..12) {
            if (pmCue && hour < 12) {
                hour += 12
            } else if (amCue && hour == 12) {
                hour = 0
            } else if (!pmCue && !amCue) {
                val now = Calendar.getInstance()
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val c1 = (hour % 12) * 60 + m
                val c2 = c1 + 720
                fun delta(x: Int) = (x - nowMin + 1440) % 1440
                hour = (if (delta(c1) <= delta(c2)) c1 else c2) / 60
            }
        }
        return hour to m
    }

    private fun setAlarm(t: String) {
        val hm = parseTime(t)
        if (hm == null) {
            say("எந்த நேரத்துக்கு அலாரம் வைக்கணும்?", "What time should I set the alarm for?")
            return
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hm.first)
            putExtra(AlarmClock.EXTRA_MINUTES, hm.second)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Edith")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        startAct(i)
        val mm = hm.second.toString().padStart(2, '0')
        say("${hm.first}:$mm க்கு அலாரம் வச்சிட்டேன்", "Alarm set for ${hm.first}:$mm")
    }

    private fun dismissAlarm(t: String) {
        val all = has(t, listOf("all", "எல்லா", "ellam", "எல்லாம்"))
        val i = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
            putExtra(
                AlarmClock.EXTRA_ALARM_SEARCH_MODE,
                if (all) AlarmClock.ALARM_SEARCH_MODE_ALL else AlarmClock.ALARM_SEARCH_MODE_NEXT
            )
        }
        startAct(i)
        say("அலாரம் ஆஃப் பண்ணிட்டேன்", "Alarm turned off")
    }
}
