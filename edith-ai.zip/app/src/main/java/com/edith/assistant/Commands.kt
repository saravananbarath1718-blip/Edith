package com.edith.assistant

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.telephony.SmsManager
import android.view.KeyEvent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import java.util.Calendar

/**
 * Tamil / Tanglish / English voice commands.
 * Wake word "Edith" venum. Venaam na REQUIRE_WAKE = false pannunga.
 */
class Commands(private val ctx: Context, private val say: (String, String) -> Unit) {

    companion object {
        const val REQUIRE_WAKE = true
        val WAKE = listOf("edith", "edit", "எடித்", "எடிட்", "ஈடித்", "எடித", "ஈடிட்")
    }

    private val alarmW = listOf("alarm", "அலாரம்", "அலாரத்தை", "அலார்ம்")
    private val cancelW = listOf("cancel", "delete", "ரத்து", "நீக்கு")
    private val offW = listOf("off", "ஆஃப்", "அணை", "நிறுத்து", "நிறுத்து", "stop")
    private val rejectW = listOf("reject", "cut", "decline", "hang", "கட்", "ரிஜெக்ட்", "நிராகரி", "துண்டி")
    private val callW = listOf("call", "phone", "dial", "கால்", "போன்", "அழை", "கூப்பிடு", "பேசு")
    private val flashW = listOf("torch", "flash", "light", "டார்ச்", "ஃப்ளாஷ்", "ஃபிளாஷ்", "ப்ளாஷ்", "விளக்கு", "லைட்")
    private val timeW = listOf("time", "நேரம்", "டைம்", "மணி")
    private val calW = listOf("calendar", "calender", "கேலண்டர்", "நாள்காட்டி", "நாட்காட்டி")
    private val mapW = listOf("map", "maps", "மேப்", "மேப்ஸ்", "வரைபடம்", "navigate", "வழி")
    private val searchW = listOf("search", "தேடு", "தேடி", "சர்ச்")
    private val closeW = listOf("close", "மூடு", "குளோஸ்", "க்ளோஸ்")
    private val openW = listOf("open", "ஓபன்", "திற", "தொற", "தெற", "thira")
    private val fillers = listOf(
        "pannu", "pannunga", "பண்ணு", "பண்ணுங்க", "பன்னு", "செய்", "sollu", "please", "pls",
        "vai", "வை", "kku", "க்கு", "ku", "la", "ல", "ஒரு", "on", "ஆன்", "போடு", "podu"
    )
    private val msgW = listOf("message", "msg", "sms", "மெசேஜ்", "எஸ்எம்எஸ்")
    private val scrollW = listOf("scroll", "ஸ்க்ரோல்", "ஸ்கிரோல்", "ஸ்க்ரால்")
    private val nextW = listOf("next", "அடுத்த", "நெக்ஸ்ட்")
    private val prevW = listOf("previous", "prev", "முந்தைய", "ப்ரீவியஸ்")
    private val upTok = setOf("up", "மேல", "மேலே", "அப்")

    private val clickWords = listOf("click", "tap", "touch", "press", "கிளிக்", "டாப்", "தொடு", "அழுத்து")
    private val linkW = listOf("link", "லிங்க்", "லிங்", "result", "ரிசல்ட்")
    private val centerTok = setOf("center", "centre", "middle", "நடு", "நடுவில்", "நடுவுல", "நடுவாக", "மிடில்")

    private enum class Stage { NONE, BODY, CONFIRM }
    private var stage = Stage.NONE
    private var stageTime = 0L
    private var msgName = ""
    private var msgNum = ""
    private var msgBody = ""
    private var msgSms = false

    private val allKeywords = alarmW + cancelW + offW + rejectW + callW + flashW + timeW +
        calW + mapW + searchW + closeW + openW

    private val aliases = mapOf(
        "வாட்ஸ்அப்" to "whatsapp", "வாட்ஸ் அப்" to "whatsapp", "யூடியூப்" to "youtube",
        "யூட்யூப்" to "youtube", "கேமரா" to "camera", "குரோம்" to "chrome",
        "இன்ஸ்டாகிராம்" to "instagram", "பேஸ்புக்" to "facebook", "டெலிகிராம்" to "telegram",
        "செட்டிங்ஸ்" to "settings", "செட்டிங்" to "settings", "கேலரி" to "gallery",
        "கடிகாரம்" to "clock", "கிளாக்" to "clock", "மெசேஜ்" to "messages",
        "கால்குலேட்டர்" to "calculator", "ஸ்பாட்டிஃபை" to "spotify", "ஜிமெயில்" to "gmail",
        "கூகுள் பே" to "google pay", "போன்பே" to "phonepe", "வாட்சப்" to "whatsapp", "வாட்ஸ்ஆப்" to "whatsapp", "வாட்சாப்" to "whatsapp", "பிளே ஸ்டோர்" to "play store"
    )

    /** partial=true: pesikittu irukkumbothe seyal. Clarification/not-found pesaama, alarm/search/map ku wait pannum. */
    fun handle(results: List<String>, partial: Boolean = false): Boolean {
        for (r in results) if (process(r, partial)) return true
        return false
    }

    private fun has(t: String, l: List<String>) = l.any { t.contains(it) }

    private fun toks(t: String) = t.split(Regex("\\s+")).map { it.trim('.', ',', '!', '?', '"') }

    private fun process(raw: String, partial: Boolean): Boolean {
        if (stage != Stage.NONE) {
            if (System.currentTimeMillis() - stageTime > 40000) {
                stage = Stage.NONE
            } else {
                return if (partial) false else handlePending(raw)
            }
        }
        var t = raw.lowercase().trim()
        val requireWake = ctx.getSharedPreferences("edith", Context.MODE_PRIVATE).getBoolean("wake", false)
        if (requireWake) {
            val w = WAKE.firstOrNull { t.contains(it) } ?: return false
            t = t.replace(w, " ")
        }
        for ((k, v) in aliases) t = t.replace(k, v)
        t = t.replace(Regex("\\s+"), " ").trim()
        val rest = strip(t)

        if (t.isEmpty()) {
            if (partial) return false
            say("சொல்லுங்க", "Yes?")
            return true
        }
        if (has(t, alarmW)) {
            if (partial) return false
            if (has(t, offW) || has(t, cancelW)) dismissAlarm(t) else setAlarm(t)
            return true
        }
        if (has(t, msgW)) {
            if (partial) return false
            val restMsg = rest.split(" ").filter { w ->
                !(w.startsWith("message") || w == "msg" || w == "sms" || w == "whatsapp" || w == "text" || w.startsWith("எஸ்எம்எஸ்"))
            }.joinToString(" ")
            if (startMessage(t, restMsg)) return true
            if (!has(t, openW)) {
                say("யாருக்கு மெசேஜ் அனுப்பணும்? பெயரோட சொல்லுங்க", "Who should I message? Say the name too")
                return true
            }
        }
        if (has(t, scrollW) || has(t, nextW) || has(t, prevW)) {
            val svc = EdithAccessibilityService.instance
            if (svc == null) {
                if (partial) return false
                say("Accessibility ON பண்ணுங்க", "Please turn on accessibility for Edith")
                return true
            }
            val up = !(has(t, prevW) || toks(t).any { it in upTok })
            svc.swipe(up)
            return true
        }
        val tk = toks(t)
        if (tk.contains("back") || tk.contains("பேக்")) {
            EdithAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return true
        }
        if (tk.contains("home") || tk.contains("ஹோம்")) {
            EdithAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            return true
        }
        if (tk.contains("pause") || tk.contains("பாஸ்") || tk.contains("resume")) {
            val code = if (tk.contains("resume")) KeyEvent.KEYCODE_MEDIA_PLAY else KeyEvent.KEYCODE_MEDIA_PAUSE
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            return true
        }
        val ord = ordinal(t)
        if (ord > 0 && has(t, linkW)) {
            val svc = EdithAccessibilityService.instance
            if (svc == null) {
                if (partial) return false
                say("Accessibility ON பண்ணுங்க", "Please turn on accessibility for Edith")
                return true
            }
            if (!svc.clickNthLink(ord)) {
                if (partial) return false
                say("அந்த link கிடைக்கலை", "I could not find that link")
            }
            return true
        }
        if (tk.any { w -> clickWords.any { w == it || w.startsWith(it) } }) {
            if (partial) return false
            val svc = EdithAccessibilityService.instance
            if (svc == null) {
                say("Accessibility ON பண்ணுங்க", "Please turn on accessibility for Edith")
                return true
            }
            val skip = setOf("the", "on", "this", "button", "இந்த", "அந்த")
            val target = rest.split(" ").filter { w ->
                w.isNotBlank() && w !in skip && !clickWords.any { w == it || w.startsWith(it) }
            }.joinToString(" ")
            if (target.isBlank() || tk.any { it in centerTok }) {
                svc.tapCenter()
            } else {
                val tsk = tokensSk(target)
                if (!svc.clickBestMatch { text -> score(target, tsk, text) }) {
                    say("திரையில அது கிடைக்கலை", "I could not find that on the screen")
                }
            }
            return true
        }
        if (has(t, rejectW) && (has(t, callW) || isRinging())) {
            rejectCall(); return true
        }
        if (has(t, flashW)) {
            torch(!has(t, offW)); return true
        }
        if (has(t, timeW)) {
            tellTime(); return true
        }
        if (has(t, calW)) {
            startAct(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
            say("கேலண்டர் திறக்கிறேன்", "Opening calendar")
            return true
        }
        if (has(t, mapW)) {
            if (partial) return false
            val uri = if (rest.isBlank()) "geo:0,0" else "geo:0,0?q=" + Uri.encode(rest)
            startAct(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
            say("மேப் திறக்கிறேன்", "Opening maps")
            return true
        }
        if (has(t, searchW)) {
            if (partial) return false
            if (rest.isBlank()) {
                say("என்ன தேடணும்?", "What should I search?")
            } else {
                startAct(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, rest))
                say("தேடுகிறேன்", "Searching")
            }
            return true
        }
        if (has(t, closeW)) {
            val svc = EdithAccessibilityService.instance
            if (svc == null) {
                say("Accessibility ON பண்ணுங்க", "Please turn on accessibility for Edith")
            } else if (t.split(" ").any { it == "all" || it == "ellam" || it.startsWith("எல்லா") || it.startsWith("அனைத்து") }) {
                svc.closeAllApps()
                say("எல்லா app-உம் மூடுறேன்", "Closing all apps")
            } else {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                say("சரி", "Done")
            }
            return true
        }
        if (has(t, callW) && callContact(rest)) return true
        if (openApp(rest)) return true
        if (has(t, callW)) {
            if (partial) return false
            say("அந்த contact கிடைக்கலை", "I could not find that contact")
            return true
        }
        if (has(t, openW)) {
            if (partial) return false
            say("அந்த app கிடைக்கலை", "I could not find that app")
            return true
        }
        if (requireWake && !partial) {
            say("புரியலை, மறுபடி சொல்லுங்க", "Sorry, I did not understand")
            return true
        }
        return false
    }

    // ---------- helpers ----------

    private fun strip(t: String): String {
        val kws = allKeywords + fillers
        return t.split(Regex("\\s+")).filter { tok ->
            tok.isNotBlank() && !kws.any { k -> tok == k || (k.length >= 3 && tok.startsWith(k)) }
        }.joinToString(" ")
    }

    private fun startAct(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = EdithAccessibilityService.instance ?: ctx
        try {
            c.startActivity(i)
        } catch (e: Exception) {
            say("திறக்க முடியலை", "Could not open it")
        }
    }

    private val tamilMap = mapOf(
        'க' to 'k', 'ங' to 'n', 'ச' to 's', 'ஞ' to 'n', 'ட' to 't', 'ண' to 'n', 'த' to 't',
        'ந' to 'n', 'ப' to 'p', 'ம' to 'm', 'ய' to 'y', 'ர' to 'r', 'ல' to 'l', 'வ' to 'v',
        'ழ' to 'l', 'ள' to 'l', 'ற' to 'r', 'ன' to 'n', 'ஜ' to 'j', 'ஷ' to 's', 'ஸ' to 's', 'ஹ' to 'h'
    )

    /** Tamil & English ellathaiyum oru "consonant skeleton" aa maathum, fuzzy match ku. */
    private fun skeleton(w: String): String {
        val s = w.lowercase()
            .replace("ch", "s").replace("sh", "s").replace("th", "t").replace("dh", "t")
            .replace("kh", "k").replace("gh", "k").replace("ph", "p").replace("bh", "p")
        val sb = StringBuilder()
        for (ch in s) {
            val m = tamilMap[ch]
            if (m != null) {
                sb.append(m)
            } else if (ch in 'a'..'z' && ch !in "aeiou") {
                sb.append(
                    when (ch) {
                        'g', 'c', 'q', 'x' -> 'k'
                        'd' -> 't'
                        'b', 'f' -> 'p'
                        'z' -> 's'
                        'w' -> 'v'
                        else -> ch
                    }
                )
            }
        }
        return sb.toString()
    }

    private fun score(rest: String, tokSk: List<String>, name: String): Int {
        val n = name.lowercase().trim()
        if (n.length >= 3 && rest.contains(n)) return 100 + n.length
        var s = 0
        for (nt in n.split(Regex("[\\s._\\-]+")).filter { it.isNotEmpty() }) {
            val ns = skeleton(nt)
            if (ns.length >= 2 && tokSk.any { it.startsWith(ns) }) s += ns.length
        }
        return s
    }

    private fun tokensSk(rest: String) =
        rest.split(Regex("\\s+")).filter { it.isNotBlank() }.map { skeleton(it) }

    private fun ordinal(t: String): Int {
        val m = listOf(
            1 to listOf("first", "1st", "முதல்", "ஒன்னாவது", "ஒன்றாவது"),
            2 to listOf("second", "2nd", "இரண்டாவது", "ரெண்டாவது", "ரெண்டாம்"),
            3 to listOf("third", "3rd", "மூன்றாவது", "மூணாவது"),
            4 to listOf("fourth", "4th", "நான்காவது", "நாலாவது"),
            5 to listOf("fifth", "5th", "ஐந்தாவது", "அஞ்சாவது")
        )
        val tk = toks(t)
        for ((n, ws) in m) {
            if (tk.any { w -> ws.any { w == it || w.startsWith(it) } }) return n
        }
        val d = tk.firstOrNull { it.length == 1 && it[0] in '1'..'9' }
        return d?.toInt() ?: 0
    }

    // ---------- messaging ----------

    private fun findContact(rest: String): Pair<String, String>? {
        if (rest.isBlank()) return null
        val tokSk = tokensSk(rest)
        var bn: String? = null
        var bu: String? = null
        var bs = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val sc = score(rest, tokSk, name)
                    if (sc > bs) { bs = sc; bn = name; bu = num }
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        val n = bn
        val u = bu
        return if (n != null && u != null && bs >= 2) n to u else null
    }

    private fun startMessage(t: String, restMsg: String): Boolean {
        val c = findContact(restMsg) ?: return false
        msgName = c.first
        msgNum = c.second
        val saidSms = toks(t).any { it == "sms" || it == "text" || it.startsWith("எஸ்எம்எஸ்") }
        msgSms = saidSms || ctx.packageManager.getLaunchIntentForPackage("com.whatsapp") == null
        stage = Stage.BODY
        stageTime = System.currentTimeMillis()
        say("$msgName க்கு என்ன மெசேஜ்?", "What message for $msgName?")
        return true
    }

    private fun handlePending(raw: String): Boolean {
        val t = raw.lowercase().trim()
        val tk = toks(t)
        if (tk.any { it == "cancel" || it == "வேண்டாம்" || it == "ரத்து" || it == "stop" }) {
            stage = Stage.NONE
            say("சரி, ரத்து பண்ணிட்டேன்", "Cancelled")
            return true
        }
        if (stage == Stage.BODY) {
            msgBody = raw.trim()
            stage = Stage.CONFIRM
            stageTime = System.currentTimeMillis()
            say(
                "\"$msgBody\" ன்னு $msgName க்கு அனுப்பவா? ஆமா இல்ல வேண்டாம்னு சொல்லுங்க",
                "Send \"$msgBody\" to $msgName? Say yes or no"
            )
            return true
        }
        val no = setOf("no", "இல்ல", "இல்லை", "நோ")
        val yes = setOf("yes", "yeah", "ok", "okay", "send", "confirm", "ஆமா", "ஆம்", "ஆமாம்", "சரி", "அனுப்பு", "அனுப்புங்க", "ஓகே", "எஸ்")
        if (tk.any { it in no }) {
            stage = Stage.NONE
            say("சரி, அனுப்பலை", "Okay, not sending")
            return true
        }
        if (tk.any { it in yes }) {
            stage = Stage.NONE
            if (msgSms) sendSms() else sendWhatsapp()
            return true
        }
        stageTime = System.currentTimeMillis()
        say("ஆமா இல்ல வேண்டாம்னு சொல்லுங்க", "Please say yes or no")
        return true
    }

    @Suppress("DEPRECATION")
    private fun sendSms() {
        try {
            val sm = SmsManager.getDefault()
            sm.sendMultipartTextMessage(msgNum, null, sm.divideMessage(msgBody), null, null)
            say("மெசேஜ் அனுப்பிட்டேன்", "Message sent")
        } catch (e: SecurityException) {
            say("SMS permission கொடுங்க", "Please give SMS permission")
        } catch (e: Exception) {
            say("மெசேஜ் அனுப்ப முடியலை", "Could not send the message")
        }
    }

    private fun sendWhatsapp() {
        val digits = msgNum.filter { it.isDigit() }
        val intl = when {
            msgNum.trim().startsWith("+") -> digits
            digits.length == 10 -> "91$digits"
            digits.length == 11 && digits.startsWith("0") -> "91" + digits.drop(1)
            else -> digits
        }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=" + Uri.encode(msgBody)))
            .setPackage("com.whatsapp")
        startAct(i)
        val svc = EdithAccessibilityService.instance
        if (svc == null) {
            say("Accessibility ON பண்ணுங்க, அப்போ தான் தானா send ஆகும்", "Turn on accessibility to send automatically")
        } else {
            svc.autoClickSend()
            say("WhatsApp-ல அனுப்புறேன்", "Sending on WhatsApp")
        }
    }

    // ---------- actions ----------

    private fun openApp(rest: String): Boolean {
        if (rest.isBlank()) return false
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val tokSk = tokensSk(rest)
        var best: ResolveInfo? = null
        var bs = 0
        for (ri in pm.queryIntentActivities(li, 0)) {
            val s = score(rest, tokSk, ri.loadLabel(pm).toString())
            if (s > bs) { bs = s; best = ri }
        }
        val b = best
        if (b == null || bs < 3) return false
        val launch = pm.getLaunchIntentForPackage(b.activityInfo.packageName) ?: return false
        say("${b.loadLabel(pm)} திறக்கிறேன்", "Opening ${b.loadLabel(pm)}")
        startAct(launch)
        return true
    }

    private fun callContact(rest: String): Boolean {
        if (rest.isBlank()) return false
        val tokSk = tokensSk(rest)
        var bestName: String? = null
        var bestNum: String? = null
        var bestScore = 0
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val s = score(rest, tokSk, name)
                    if (s > bestScore) { bestScore = s; bestName = name; bestNum = num }
                }
            }
        } catch (e: SecurityException) {
            say("Contacts permission கொடுங்க", "Please give contacts permission")
            return true
        }
        val nm = bestName
        val nu = bestNum
        if (nm == null || nu == null || bestScore < 2) return false
        say("$nm க்கு கால் பண்றேன்", "Calling $nm")
        startAct(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(nu))))
        return true
    }

    private fun isRinging(): Boolean = try {
        (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager)
            .callState == TelephonyManager.CALL_STATE_RINGING
    } catch (e: Exception) {
        false
    }

    @Suppress("DEPRECATION")
    private fun rejectCall() {
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val ok = tm.endCall()
            if (ok) say("கால் கட் பண்ணிட்டேன்", "Call ended")
        } catch (e: SecurityException) {
            say("Phone permission கொடுங்க", "Please give phone permission")
        }
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                say("Flash இல்லை", "No flashlight found")
                return
            }
            cm.setTorchMode(id, on)
            say(if (on) "டார்ச் ஆன்" else "டார்ச் ஆஃப்", if (on) "Torch on" else "Torch off")
        } catch (e: Exception) {
            say("டார்ச் வேலை செய்யலை", "Torch failed")
        }
    }

    private fun tellTime() {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val m = c.get(Calendar.MINUTE)
        val am = c.get(Calendar.AM_PM) == Calendar.AM
        val mm = m.toString().padStart(2, '0')
        say(
            "இப்போது ${if (am) "காலை" else "மாலை"} $h மணி $m நிமிடம்",
            "It is $h:$mm ${if (am) "AM" else "PM"}"
        )
    }

    private val tamilNums = listOf(
        "பன்னிரண்டு" to 12, "பதினொன்று" to 11, "ஒன்பது" to 9, "இரண்டு" to 2, "மூன்று" to 3,
        "நான்கு" to 4, "ஐந்து" to 5, "பத்து" to 10, "ஒன்று" to 1, "ஆறு" to 6, "ஏழு" to 7,
        "எட்டு" to 8, "ஒரு" to 1
    )

    private fun parseTime(t: String): Pair<Int, Int>? {
        var h: Int? = null
        var m = 0
        val r1 = Regex("\\b(\\d{1,2})\\s*[:.]\\s*(\\d{2})\\b").find(t)
            ?: Regex("\\b(\\d{1,2})\\s+(\\d{2})\\b").find(t)
        if (r1 != null) {
            h = r1.groupValues[1].toInt()
            m = r1.groupValues[2].toInt()
        } else {
            val r2 = Regex("\\b(\\d{1,2})\\b").find(t)
            if (r2 != null) {
                h = r2.groupValues[1].toInt()
            } else {
                h = tamilNums.firstOrNull { t.contains(it.first) }?.second
            }
            if (t.contains("அரை") || t.contains("half")) m = 30
        }
        if (h == null || h > 23 || m > 59) return null

        val pmCue = has(t, listOf("மாலை", "evening", "night", "இரவு", "நைட்", "மதியம்", "afternoon", "பிற்பகல்")) ||
            Regex("\\bp\\.?m\\b").containsMatchIn(t)
        val amCue = has(t, listOf("காலை", "morning", "அதிகாலை", "விடியற்காலை")) ||
            Regex("\\ba\\.?m\\b").containsMatchIn(t)

        var hour: Int = h
        if (hour in 1..12) {
            if (pmCue && hour < 12) {
                hour += 12
            } else if (amCue && hour == 12) {
                hour = 0
            } else if (!pmCue && !amCue) {
                val now = Calendar.getInstance()
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val c1 = (hour % 12) * 60 + m
                val c2 = c1 + 720
                fun delta(x: Int) = (x - nowMin + 1440) % 1440
                hour = (if (delta(c1) <= delta(c2)) c1 else c2) / 60
            }
        }
        return hour to m
    }

    private fun setAlarm(t: String) {
        val hm = parseTime(t)
        if (hm == null) {
            say("எந்த நேரத்துக்கு அலாரம் வைக்கணும்?", "What time should I set the alarm for?")
            return
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hm.first)
            putExtra(AlarmClock.EXTRA_MINUTES, hm.second)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Edith")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        startAct(i)
        val mm = hm.second.toString().padStart(2, '0')
        say("${hm.first}:$mm க்கு அலாரம் வச்சிட்டேன்", "Alarm set for ${hm.first}:$mm")
    }

    private fun dismissAlarm(t: String) {
        val all = has(t, listOf("all", "எல்லா", "ellam", "எல்லாம்"))
        val i = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
            putExtra(
                AlarmClock.EXTRA_ALARM_SEARCH_MODE,
                if (all) AlarmClock.ALARM_SEARCH_MODE_ALL else AlarmClock.ALARM_SEARCH_MODE_NEXT
            )
        }
        startAct(i)
        say("அலாரம் ஆஃப் பண்ணிட்டேன்", "Alarm turned off")
    }
}
