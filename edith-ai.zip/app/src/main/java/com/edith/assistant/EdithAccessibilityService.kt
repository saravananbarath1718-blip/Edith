package com.edith.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class EdithAccessibilityService : AccessibilityService() {
    companion object {
        var instance: EdithAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Recents screen thorandhu "Close all / Clear all" button ah click pannum. Phone ku phone maarum. */
    fun closeAllApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({ clickClearAll(0) }, 900)
    }

    private fun clickClearAll(attempt: Int) {
        val root = rootInActiveWindow
        var done = false
        if (root != null) {
            val labels = listOf("close all", "clear all", "clear", "close")
            outer@ for (l in labels) {
                for (n in root.findAccessibilityNodeInfosByText(l)) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable) x = x.parent
                    if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        done = true
                        break@outer
                    }
                }
            }
        }
        if (!done && attempt < 3) {
            handler.postDelayed({ clickClearAll(attempt + 1) }, 600)
        } else {
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 600)
        }
    }
}
