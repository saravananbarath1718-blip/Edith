package com.edith.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class EdithAccessibilityService : AccessibilityService() {
    companion object {
        var instance: EdithAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** up=true: viral mela swipe (content keezha scroll / next video). */
    fun swipe(up: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val h = dm.heightPixels.toFloat()
        val y1 = if (up) h * 0.75f else h * 0.30f
        val y2 = if (up) h * 0.30f else h * 0.75f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250))
            .build()
        dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    fun tapCenter() {
        val dm = resources.displayMetrics
        tap(dm.widthPixels / 2f, dm.heightPixels / 2f)
    }

    private fun clickableTarget(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var x: AccessibilityNodeInfo? = n
        var d = 0
        while (x != null && d < 6 && !x.isClickable) {
            x = x.parent
            d++
        }
        return if (x != null && x.isClickable) x else null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        val t = clickableTarget(n)
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val b = Rect()
        n.getBoundsInScreen(b)
        if (b.width() > 0 && b.height() > 0) {
            tap(b.exactCenterX(), b.exactCenterY())
            return true
        }
        return false
    }

    /** Screen la irukkura text la, score athigam irukkura onnai click pannum. */
    fun clickBestMatch(score: (String) -> Int): Boolean {
        val root = rootInActiveWindow ?: return false
        var best: AccessibilityNodeInfo? = null
        var bs = 0
        var bl = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val txt = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!txt.isNullOrEmpty() && txt.length <= 60 && n.isVisibleToUser) {
                val sc = score(txt)
                if (sc > bs || (sc == bs && sc > 0 && txt.length < bl)) {
                    bs = sc
                    bl = txt.length
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val b = best
        return b != null && bs >= 2 && clickNode(b)
    }

    private fun collectLinks(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, h: Int) {
        if (n == null) return
        val txt = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
        if (txt.length >= 12 && n.isVisibleToUser) {
            val t = clickableTarget(n)
            if (t != null) {
                val b = Rect()
                t.getBoundsInScreen(b)
                if (b.top > h * 0.12f && b.bottom < h * 0.97f && b.height() > 40) {
                    val dup = out.any { o ->
                        val ob = Rect()
                        o.getBoundsInScreen(ob)
                        ob == b
                    }
                    if (!dup) out.add(t)
                }
            }
        }
        for (i in 0 until n.childCount) collectLinks(n.getChild(i), out, h)
    }

    /** Screen la mela irundhu keezha n-vadhu link ah click pannum (Google results ku). */
    fun clickNthLink(n: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val h = resources.displayMetrics.heightPixels
        val found = ArrayList<AccessibilityNodeInfo>()
        collectLinks(root, found, h)
        found.sortBy { r ->
            val b = Rect()
            r.getBoundsInScreen(b)
            b.top
        }
        if (n < 1 || n > found.size) return false
        return clickNode(found[n - 1])
    }

    /** WhatsApp chat thorandhu "Send" button ah thaana click pannum. */
    fun autoClickSend() {
        handler.postDelayed({ trySend(0) }, 2500)
    }

    private fun findSend(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()
        if (d != null && (d.equals("Send", true) || d == "அனுப்பு")) return n
        for (i in 0 until n.childCount) {
            val r = findSend(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun trySend(attempt: Int) {
        val root = rootInActiveWindow
        var done = false
        if (root != null && root.packageName?.toString()?.startsWith("com.whatsapp") == true) {
            var x: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
                ?: findSend(root)
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) done = true
        }
        if (!done && attempt < 10) handler.postDelayed({ trySend(attempt + 1) }, 700)
    }

    /** Recents screen thorandhu "Close all / Clear all" button ah click pannum. Phone ku phone maarum. */
    fun closeAllApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({ clickClearAll(0) }, 900)
    }

    private fun clickClearAll(attempt: Int) {
        val root = rootInActiveWindow
        var done = false
        if (root != null) {
            val labels = listOf("close all", "clear all", "clear", "close")
            outer@ for (l in labels) {
                for (n in root.findAccessibilityNodeInfosByText(l)) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable) x = x.parent
                    if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        done = true
                        break@outer
                    }
                }
            }
        }
        if (!done && attempt < 3) {
            handler.postDelayed({ clickClearAll(attempt + 1) }, 600)
        } else {
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 600)
        }
    }
}
