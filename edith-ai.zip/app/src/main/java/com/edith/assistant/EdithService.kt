package com.edith.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class EdithService : Service(), TextToSpeech.OnInitListener {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var tamilOk = false
    private var running = false
    private var speaking = false
    private lateinit var commands: Commands
    private val listenRunnable = Runnable { startListening() }
    private val unmuteRunnable = Runnable { muteBeep(false) }
    private lateinit var audio: AudioManager

    /** Speech recognizer beep (tak tak) ah mute panna. */
    private fun muteBeep(mute: Boolean) {
        if (mute) handler.removeCallbacks(unmuteRunnable)
        val d = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try { audio.adjustStreamVolume(st, d, 0) } catch (e: Exception) { }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        audio = getSystemService(AudioManager::class.java)
        val channel = NotificationChannel("edith", "Edith", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "edith")
            .setContentTitle("Edith")
            .setContentText("Kettukittu irukken...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        commands = Commands(this) { ta, en -> speak(ta, en) }
        tts = TextToSpeech(this, this)
        scheduleListen(800)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("ta", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
        tamilOk = r >= TextToSpeech.LANG_AVAILABLE
        if (!tamilOk) tts?.setLanguage(Locale.US)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(300) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(300) }
            }
        })
        ttsReady = true
    }

    private fun speak(ta: String, en: String) {
        if (!ttsReady) return
        speaking = true
        handler.removeCallbacks(listenRunnable)
        recognizer?.cancel()
        muteBeep(false)
        tts?.speak(if (tamilOk) ta else en, TextToSpeech.QUEUE_FLUSH, null, "edith")
    }

    private fun scheduleListen(delayMs: Long) {
        if (!running || speaking) return
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delayMs)
    }

    private fun startListening() {
        if (!running || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        muteBeep(true)
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            handler.postDelayed(unmuteRunnable, 500)
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            muteBeep(true)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            muteBeep(true)
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf()
                return
            }
            if (error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT && error != SpeechRecognizer.ERROR_NO_MATCH) {
                recognizer?.destroy()
                recognizer = null
            }
            scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 150)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            if (list.isNotEmpty()) {
                Toast.makeText(this@EdithService, "Kettathu: " + list[0], Toast.LENGTH_SHORT).show()
            }
            try {
                commands.handle(list)
            } catch (e: Exception) {
                // ignore, keep listening
            }
            if (!speaking) scheduleListen(100)
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        muteBeep(false)
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
