package com.edith.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "EDITH"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Step 1 to 4 order la press pannunga. Appuram \"Edith start\". " +
                "Pesumbothu munnadi \"Edith\" nu sollunga. Udhaaranam: " +
                "\"Edith, torch on pannu\", \"Edith, amma ku call pannu\", \"Edith, 6:30 ku alarm vai\"."
        })

        fun btn(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            })
        }

        btn("1. Permissions kudu (mic, phone, contacts)") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_PHONE_STATE
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        btn("2. Display over other apps allow pannu") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("3. Accessibility la Edith ON pannu") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("4. Battery restriction vendaam (unrestricted)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("Edith start") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Mudhalla step 1 la mic permission kudunga", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, EdithService::class.java))
                Toast.makeText(this, "Edith start aachu", Toast.LENGTH_SHORT).show()
            }
        }
        btn("Edith stop") {
            stopService(Intent(this, EdithService::class.java))
        }

        setContentView(ScrollView(this).apply {
            addView(root)
            visibility = View.VISIBLE
        })
    }
}
